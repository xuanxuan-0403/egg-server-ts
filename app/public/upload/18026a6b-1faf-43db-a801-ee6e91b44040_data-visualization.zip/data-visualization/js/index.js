$(function () {
    // * 当修改浏览器窗口大小时自动刷新页面
    $(window).resize(function () {
        window.location.reload();
    });
    // * 监控模块
    // ! js文件中，会有大量的变量命名，特别是Echarts使用中，需要大量初始化Echarts对象？
    // ! 为了防止变量名冲突（变量污染）
    // ! 我们采用立即执行函数策略：
    (function () {
        $('.monitor .tabs').on('click', 'a', function () {
            $(this).addClass('active').siblings('a').removeClass('active');
            // console.log($(this).index());
            // 选取对应索引号的content
            $('.monitor .content')
                .eq($(this).index())
                .show()
                .siblings('.content')
                .hide();
        });
        // 滚动marquee
        $('.marquee-view .marquee').each(function () {
            // console.log($(this));
            var rows = $(this).children().clone();
            $(this).append(rows);
        });
    })();
    // * 点位分布模块
    (function () {
        // 1. 实例化对象
        var myChart = echarts.init(document.querySelector('.pie'));
        // 2. 指定配置项和数据
        var option = {
            color: [
                '#006cff',
                '#60cda0',
                '#ed8884',
                '#ff9f7f',
                '#0096ff',
                '#9fe6b8',
                '#32c5e9',
                '#1d9dff',
            ],
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b} : {c} ({d}%)',
            },
            series: [
                {
                    name: '点位统计',
                    type: 'pie',
                    radius: ['15%', '80%'],
                    center: ['50%', '50%'],
                    roseType: 'radius',
                    itemStyle: {
                        borderRadius: 5,
                    },
                    data: [
                        { value: 20, name: '云南' },
                        { value: 26, name: '北京' },
                        { value: 24, name: '山东' },
                        { value: 25, name: '河北' },
                        { value: 20, name: '江苏' },
                        { value: 25, name: '浙江' },
                        { value: 30, name: '四川' },
                        { value: 42, name: '湖北' },
                    ],
                    // 文字相关样式
                    label: {
                        fontSize: 10,
                    },
                    // 引导线相关样式
                    lableLine: {
                        // 连接扇形图线长
                        length: 6,
                        // 连接文字线长
                        length2: 8,
                    },
                },
            ],
        };
        // 3. 配置项和数据给实例化对象
        myChart.setOption(option);
    })();
    // * 用户模块
    (function () {
        var myChart = echarts.init(document.querySelector('.bar'));
        var option = {
            color: new echarts.graphic.LinearGradient(
                // (x1,y2) 点到点 (x2,y2) 之间进行渐变
                0,
                0,
                0,
                1,
                [
                    { offset: 0, color: '#00fffb' }, // 0 起始颜色
                    { offset: 1, color: '#0061ce' }, // 1 结束颜色
                ]
            ),
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow',
                },
            },
            grid: {
                top: '3%',
                left: '0%',
                right: '4%',
                bottom: '3%',
                containLabel: true,
                show: true,
                //grid 四条边框的颜色
                borderColor: 'rgba(0, 240, 255, 0.3)',
            },
            xAxis: [
                {
                    type: 'category',
                    data: [
                        '上海',
                        '广州',
                        '北京',
                        '深圳',
                        '合肥',
                        '',
                        '......',
                        '',
                        '杭州',
                        '厦门',
                        '济南',
                        '成都',
                        '重庆',
                    ],
                    axisTick: {
                        alignWithLabel: true,
                        show: false,
                    },
                    axisLabel: {
                        color: '#4c9bfd',
                    },
                    // x轴这条线的颜色样式
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(0, 240, 255, 0.3)',
                            // width: 3
                        },
                    },
                },
            ],
            yAxis: [
                {
                    type: 'value',
                    axisTick: {
                        alignWithLabel: false,
                        // 把y轴的刻度隐藏起来
                        show: false,
                    },
                    axisLabel: {
                        color: '#4c9bfd',
                    },
                    // y轴这条线的颜色样式
                    axisLine: {
                        lineStyle: {
                            color: 'rgba(0, 240, 255, 0.3)',
                            // width: 3
                        },
                    },
                    // y轴分割线的颜色样式
                    splitLine: {
                        lineStyle: {
                            color: 'rgba(0, 240, 255, 0.3)',
                        },
                    },
                },
            ],
            series: [
                {
                    name: '用户统计',
                    type: 'bar',
                    barWidth: '60%',
                    data: [
                        2100, 1900, 1700, 1560, 1400, 1200, 1200, 1200, 900,
                        750, 600, 480, 240,
                    ],
                },
            ],
        };
        myChart.setOption(option);
    })();
    // * 订单模块
    (function () {
        // 准备数据
        var data = {
            day365: { orders: '20,301,987', amount: '99834' },
            day90: { orders: '301,987', amount: '9834' },
            day30: { orders: '1,987', amount: '3834' },
            day1: { orders: '987', amount: '834' },
        };
        $('.order .filter').on('click', 'a', function () {
            // 点击切换样式
            $(this).addClass('active').siblings('a').removeClass('active');
            // console.log($(this).index());
            // 获取页面中的data-key属性
            var key = $(this).attr('data-key');
            // 获取对应的数据
            var currData = data[key];
            // 把数据渲染进去
            $('.order .item h4').eq(0).html(currData.orders);
            $('.order .item h4').eq(1).html(currData.amount);
        });
        // 鼠标经过就停止定时器
        $('.order .inner').mouseenter(function () {
            clearInterval(timer);
        });
        // 鼠标离开就开启定时器
        $('.order .inner').mouseleave(function () {
            timer = setInterval(function () {
                index++;
                if (index >= 4) {
                    index = 0;
                }
                $('.order .filter a').eq(index).trigger('click');
            }, 3000);
        });
        // 开启定时器切换
        var index = 0;
        var timer = setInterval(function () {
            index++;
            if (index >= 4) {
                index = 0;
            }
            $('.order .filter a').eq(index).trigger('click');
        }, 3000);
    })();
    // * 销售统计模块
    (function () {
        // 准备数据
        var data = {
            year: [
                [24, 40, 101, 134, 90, 230, 210, 230, 120, 230, 210, 120],
                [40, 64, 191, 324, 290, 330, 310, 213, 180, 200, 180, 79],
            ],
            quarter: [
                [23, 75, 12, 97, 21, 67, 98, 21, 43, 64, 76, 38],
                [43, 31, 65, 23, 78, 21, 82, 64, 43, 60, 19, 34],
            ],
            month: [
                [34, 87, 32, 76, 98, 12, 32, 87, 39, 36, 29, 36],
                [56, 43, 98, 21, 56, 87, 43, 12, 43, 54, 12, 98],
            ],
            week: [
                [43, 73, 62, 54, 91, 54, 84, 43, 86, 43, 54, 53],
                [32, 54, 34, 87, 32, 45, 62, 68, 93, 54, 54, 24],
            ],
        };
        var myChart = echarts.init(document.querySelector('.sales .line'));
        var option = {
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: [
                    '1月',
                    '2月',
                    '3月',
                    '4月',
                    '5月',
                    '6月',
                    '7月',
                    '8月',
                    '9月',
                    '10月',
                    '11月',
                    '12月',
                ],
                axisTick: {
                    show: false, // 去除刻度线
                },
                axisLabel: {
                    color: '#4c9bfd', // 文本颜色
                },
                axisLine: {
                    show: false, // 去除轴线
                },
                boundaryGap: false, // 去除轴内间距
            },
            yAxis: {
                type: 'value',
                axisTick: {
                    show: false, // 去除刻度
                },
                axisLabel: {
                    color: '#4c9bfd', // 文字颜色
                },
                splitLine: {
                    lineStyle: {
                        color: '#012f4a', // 分割线颜色
                    },
                },
            },
            series: [
                {
                    name: '预期销售额',
                    data: data.year[0],
                    type: 'line',
                    smooth: true,
                    itemStyle: {
                        color: '#00f2f1', // 线颜色
                    },
                },
                {
                    name: '实际销售额',
                    data: data.year[1],
                    type: 'line',
                    smooth: true,
                    itemStyle: {
                        color: '#ed3f35', // 线颜色
                    },
                },
            ],
            // 设置网格样式
            grid: {
                show: true, // 显示边框
                top: '20%',
                left: '3%',
                right: '4%',
                bottom: '3%',
                borderColor: '#012f4a', // 边框颜色
                containLabel: true, // 包含刻度文字在内
            },
            // 图例组件
            legend: {
                textStyle: {
                    color: '#4c9bfd', // 图例文字颜色
                },
                right: '10%', // 距离右边10%
            },
            tooltip: {
                trigger: 'axis',
            },
        };
        myChart.setOption(option);
        // 点击后切换
        $('.sales .caption').on('click', 'a', function () {
            $(this).addClass('active').siblings('a').removeClass('active');
            var key = $(this).attr('data-type');
            // console.log(key);
            var currData = data[key];
            // console.log(currData);
            option.series[0].data = currData[0];
            option.series[1].data = currData[1];
            // 重新渲染页面
            myChart.setOption(option);
        });
        // 鼠标经过就停止定时器
        $('.sales .inner').mouseenter(function () {
            clearInterval(timer);
        });
        // 鼠标离开就开启定时器
        $('.sales .inner').mouseleave(function () {
            timer = setInterval(function () {
                index++;
                if (index >= 4) {
                    index = 0;
                }
                $('.sales .caption a').eq(index).click();
            }, 1000);
        });
        // 自动切换
        var index = 0;
        var timer = setInterval(function () {
            index++;
            if (index >= 4) {
                index = 0;
            }
            $('.sales .caption a').eq(index).click();
        }, 1000);
    })();
    // * 销量进度-饼状图
    (function () {
        var myChart = echarts.init(document.querySelector('.quarter .gauge'));
        var option = {
            series: [
                {
                    name: '销售进度',
                    type: 'pie',
                    radius: ['130%', '150%'],
                    // 移动下位置  套住50%文字
                    center: ['48%', '80%'],
                    //是否启用防止标签重叠策略
                    // avoidLabelOverlap: false,
                    labelLine: {
                        normal: {
                            show: false,
                        },
                    },
                    // 饼形图的起始角度为 180， 注意不是旋转角度
                    startAngle: 180,
                    // 鼠标经过不需要放大偏移图形
                    hoverOffset: 0,
                    data: [
                        {
                            value: 100,
                            itemStyle: {
                                // 颜色渐变#00c9e0->#005fc1
                                color: new echarts.graphic.LinearGradient(
                                    // (x1,y2) 点到点 (x2,y2) 之间进行渐变
                                    0,
                                    0,
                                    0,
                                    1,
                                    [
                                        { offset: 0, color: '#00c9e0' }, // 0 起始颜色
                                        { offset: 1, color: '#005fc1' }, // 1 结束颜色
                                    ]
                                ),
                            },
                        },
                        {
                            value: 100,
                            itemStyle: {
                                color: '#12274d',
                            },
                        },
                        {
                            value: 200,
                            itemStyle: {
                                color: 'transparent',
                            },
                        },
                    ],
                },
            ],
        };
        myChart.setOption(option);
    })();
    // * 热销排行模块
    (function () {
        // 1. 准备相关数据
        var hotData = [
            {
                city: "北京", // 城市
                sales: "25, 179", // 销售额
                flag: true, //  上升还是下降
                brands: [
                    //  品牌种类数据
                    { name: "可爱多", num: "9,086", flag: true },
                    { name: "娃哈哈", num: "8,341", flag: true },
                    { name: "喜之郎", num: "7,407", flag: false },
                    { name: "八喜", num: "6,080", flag: false },
                    { name: "小洋人", num: "6,724", flag: false },
                    { name: "好多鱼", num: "2,170", flag: true }
                ]
            },
            {
                city: "河北",
                sales: "23,252",
                flag: false,
                brands: [
                    { name: "可爱多", num: "3,457", flag: false },
                    { name: "娃哈哈", num: "2,124", flag: true },
                    { name: "喜之郎", num: "8,907", flag: false },
                    { name: "八喜", num: "6,080", flag: true },
                    { name: "小洋人", num: "1,724", flag: false },
                    { name: "好多鱼", num: "1,170", flag: false }
                ]
            },
            {
                city: "上海",
                sales: "20,760",
                flag: true,
                brands: [
                    { name: "可爱多", num: "2,345", flag: true },
                    { name: "娃哈哈", num: "7,109", flag: true },
                    { name: "喜之郎", num: "3,701", flag: false },
                    { name: "八喜", num: "6,080", flag: false },
                    { name: "小洋人", num: "2,724", flag: false },
                    { name: "好多鱼", num: "2,998", flag: true }
                ]
            },
            {
                city: "江苏",
                sales: "23,252",
                flag: false,
                brands: [
                    { name: "可爱多", num: "2,156", flag: false },
                    { name: "娃哈哈", num: "2,456", flag: true },
                    { name: "喜之郎", num: "9,737", flag: true },
                    { name: "八喜", num: "2,080", flag: true },
                    { name: "小洋人", num: "8,724", flag: true },
                    { name: "好多鱼", num: "1,770", flag: false }
                ]
            },
            {
                city: "山东",
                sales: "20,760",
                flag: true,
                brands: [
                    { name: "可爱多", num: "9,567", flag: true },
                    { name: "娃哈哈", num: "2,345", flag: false },
                    { name: "喜之郎", num: "9,037", flag: false },
                    { name: "八喜", num: "1,080", flag: true },
                    { name: "小洋人", num: "4,724", flag: false },
                    { name: "好多鱼", num: "9,999", flag: true }
                ]
            }
        ];

    })()
});
